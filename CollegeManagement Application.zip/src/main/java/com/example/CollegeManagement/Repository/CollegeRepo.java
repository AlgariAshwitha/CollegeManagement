package com.example.CollegeManagement.Repository;

import com.example.CollegeManagement.Model.College;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.Optional;

public interface CollegeRepo extends JpaRepository<College, Long> {
    Optional<College> findByName(String name);
}

