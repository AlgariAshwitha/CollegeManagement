package com.example.CollegeManagement.Repository;

import com.example.CollegeManagement.Model.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FacultyRepo extends JpaRepository<Faculty, Integer> {
    List<Faculty> findByCollegeName(String collegeName);

    List<Faculty> findByDepartmentName(String departmentName);

}
