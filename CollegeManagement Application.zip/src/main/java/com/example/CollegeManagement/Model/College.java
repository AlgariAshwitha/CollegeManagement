package com.example.CollegeManagement.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@Entity
@Data
@Table(name = "college")
@AllArgsConstructor
@NoArgsConstructor
public class College {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    public String name;
    @OneToMany(mappedBy = "college", cascade = CascadeType.ALL)
    private List<Department> departments = new ArrayList<>();
    private Object id;

    public List<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(List<Department> departments) {
        this.departments = departments;
    }

    @OneToMany(mappedBy = "college", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Faculty> faculties = new ArrayList<>();

    public List<Faculty> getFaculties() {
        return faculties;
    }

    public void setFaculties(List<Faculty> faculties) {
        this.faculties = faculties;
    }


    public Long getId() {
        return (long) id;
    }

    public <id> void setId(Long id) {
        this.id = this.id;
    }

    public List getName() {
        return Collections.singletonList(name);
    }
    public void setName(String name) {
        this.name = this.name;
    }
}