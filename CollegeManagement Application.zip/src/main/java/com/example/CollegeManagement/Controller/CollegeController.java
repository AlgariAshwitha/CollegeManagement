package com.example.CollegeManagement.Controller;

import com.example.CollegeManagement.Model.College;
import com.example.CollegeManagement.Model.Department;
import com.example.CollegeManagement.Model.Faculty;
import com.example.CollegeManagement.Service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/college")
public class CollegeController {
    @Autowired
    private CollegeService CollegeService;
    @PostMapping("/addCollege")
    public College addCollege(@RequestBody College college){

        return CollegeService.addCollege(college);
    }
    @GetMapping("/all")
    public List<College> findAllColleges(){
        return CollegeService.getColleges();
    }
    @GetMapping("/id/{id}")
    public College findCollegeById(@PathVariable Long id){
        return CollegeService.getCollegeById(id);
    }
    @GetMapping("/name/{name}")
    public Optional<College> findCollegeByName(@PathVariable String name){
        return CollegeService.getCollegeByName(name);
    }
    @PutMapping("/update/{name}")
    public College updateCollegeByName(@PathVariable String name, @RequestBody College College){
        return CollegeService.updateCollegeByName(name, College);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteCollegeById(@PathVariable Long id){
        return CollegeService.deleteCollegeById(id);
    }
    @PostMapping("/{collegeId}/departments")
    public ResponseEntity<?> addDepartmentsToCollege(@PathVariable Long collegeId, @RequestBody List<Department> departments) {
        CollegeService.addDepartmentsToCollege(collegeId, departments);
        return ResponseEntity.ok().build();
    }
    @PostMapping("/{collegeId}/addFaculties")
    public ResponseEntity<String> addFacultiesToCollege(@PathVariable Long collegeId, @RequestBody List<Faculty> faculties) {
        try {
            CollegeService.addFacultiesToCollege(collegeId, faculties);
            return ResponseEntity.ok("Faculties added to college successfully.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}