package com.example.CollegeManagement.Service;


import com.example.CollegeManagement.Model.Department;
import com.example.CollegeManagement.Repository.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {
    @Autowired
    private DepartmentRepo Repo;
    public List<Department> getDepartmentsByCollegeName(String collegeName) {
        return Repo.findByCollegeName(collegeName);
    }
    public Department addDepartment(Department department) {
        return Repo.save(department);
    }
    public String getHodNameByDepartmentId(int departmentId) {
        Department department = Repo.findById(departmentId)
                .orElseThrow(() -> new RuntimeException("Department not found"));
        return department.getHodName();
    }
}
