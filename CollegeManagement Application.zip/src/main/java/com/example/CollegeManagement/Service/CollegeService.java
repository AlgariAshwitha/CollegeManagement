package com.example.CollegeManagement.Service;


import com.example.CollegeManagement.Model.College;
import com.example.CollegeManagement.Model.Department;
import com.example.CollegeManagement.Model.Faculty;
import com.example.CollegeManagement.Repository.CollegeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CollegeService {
    @Autowired
    private CollegeRepo Repo;
    public College addCollege(College college) {
        return Repo.save(college);
    }

    public List<College> getColleges() {
        return Repo.findAll();
    }

    public College getCollegeById(Long id) {
        return Repo.findById(id).orElse(null);
    }
    public Optional<College> getCollegeByName(String name) {
        return Repo.findByName(name);
    }

    public College updateCollegeByName(String name, College updatedCollege) {
        Optional<College> optionalCollege = Repo.findByName(name);
        if(optionalCollege.isPresent()){
            College existingCollege = optionalCollege.get();
            existingCollege.setId(updatedCollege.getId());
            existingCollege.setFaculties(updatedCollege.getName());
            return Repo.save(existingCollege);
        }
        else {
            throw new RuntimeException("College with name " + name + " is not found");
        }
    }

    public String deleteCollegeById(Long id) {
        Repo.deleteById(id);
        return "College with id " + id + " is deleted";
    }
    public void addDepartmentsToCollege(Long collegeId, List<Department> departments) {
        College college = Repo.findById(collegeId)
                .orElseThrow(() -> new RuntimeException("College not found"));

        for (Department department : departments) {
            department.setCollege(college);
            college.getDepartments().add(department);
        }
        Repo.save(college);
    }
    public void addFacultiesToCollege(Long collegeId, List<Faculty> faculties) {
        College college = Repo.findById(collegeId)
                .orElseThrow(() -> new RuntimeException("College not found"));

        for (Faculty faculty : faculties) {
            faculty.setCollege(college);
            college.getFaculties().add(faculty);
        }
        Repo.save(college);
    }
}
