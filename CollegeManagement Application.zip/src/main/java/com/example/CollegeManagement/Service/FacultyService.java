package com.example.CollegeManagement.Service;


import com.example.CollegeManagement.Model.Department;
import com.example.CollegeManagement.Model.Faculty;
import com.example.CollegeManagement.Repository.DepartmentRepo;
import com.example.CollegeManagement.Repository.FacultyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacultyService {
    @Autowired
    private FacultyRepo Repo;
    @Autowired
    private DepartmentRepo DRepo;
    public Faculty addFaculty(Faculty faculty) {
        return Repo.save(faculty);
    }
    public List<Faculty> getFacultiesByCollegeName(String collegeName) {
        return Repo.findByCollegeName(collegeName);
    }
    public Faculty assignFacultyToDepartment(int facultyId, int departmentId) {
        Faculty faculty = Repo.findById(facultyId)
                .orElseThrow(() -> new RuntimeException("Faculty not found"));

        Department department =  DRepo.findById(departmentId)
                .orElseThrow(() -> new RuntimeException("Department not found"));

        faculty.setDepartment(department);
        return Repo.save(faculty);
    }
    public List<Faculty> getFacultiesByDepartmentName(String departmentName) {
        return Repo.findByDepartmentName(departmentName);
    }
    public Faculty assignHodToDepartment(int facultyId, int departmentId) {
        Faculty faculty = Repo.findById(facultyId)
                .orElseThrow(() -> new RuntimeException("Faculty not found"));
        Department department = new Department();
        department.setDeptid(departmentId);

        faculty.setDepartment(department);
        return Repo.save(faculty);
    }
}
